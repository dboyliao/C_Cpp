#include <stdio.h>
#include <math.h>

int main(void)
{
    printf("fabs(-12.3)..%f\n", fabs(-12.3));
    printf("pow(2.5, 3.2)..%f\n", pow(2.5, 3.2));
    printf("fmod(3.5, 2.8)..%f\n", fmod(3.5, 2.8));
    printf("ceil(3.2)..%f\n", ceil(3.2));
    printf("floor(3.2)..%f\n", floor(3.2));
    printf("sqrt(10)..%f\n", sqrt(10));
    printf("exp(5)..%f\n", exp(5));
    printf("log10(5134)..%f\n", log10(5134));
    printf("log(35.3)..%f\n", log(35.3));
    printf("sin(0.8)..%f\n", sin(0.8));
    printf("cos(0.8)..%f\n", cos(0.8));
    printf("tan(0.8)..%f\n", tan(0.8));
    printf("asin(0.8)..%f\n", asin(0.8));
    printf("acos(0.8)..%f\n", acos(0.8));
    printf("atan(0.8)..%f\n", atan(0.8));
    printf("sinh(0.8)..%f\n", sinh(0.8));
    printf("cosh(0.8)..%f\n", cosh(0.8));
    printf("tanh(0.8)..%f\n", tanh(0.8));
}
