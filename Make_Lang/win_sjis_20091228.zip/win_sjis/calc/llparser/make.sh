cc -o mycalc lexicalanalyzer.c parser.c
